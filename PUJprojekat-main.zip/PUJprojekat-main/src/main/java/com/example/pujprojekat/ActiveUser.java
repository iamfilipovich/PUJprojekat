package com.example.pujprojekat;

import com.example.pujprojekat.model.User;

public class ActiveUser {
    public static User user = null;
}
