package com.example.pujprojekat.enums;

public enum UserType {
    WORKER,
    ADMIN
}
